#pragma once


#ifndef TASKS_INFO_H
#define TASKS_INFO_H


#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

void cli_register_tasks_info_command(void);


#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif  /* #ifndef TASKS_INFO_H */