#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void cli_register_info_command(void);

#ifdef __cplusplus
}
#endif
