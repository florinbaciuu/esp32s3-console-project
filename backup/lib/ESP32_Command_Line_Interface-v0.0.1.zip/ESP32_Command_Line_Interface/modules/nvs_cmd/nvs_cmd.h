#pragma once


#ifndef NVS_H_
#define NVS_H_


#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

void cli_register_nsv_command(void);


#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif  /* NVS_H_ */