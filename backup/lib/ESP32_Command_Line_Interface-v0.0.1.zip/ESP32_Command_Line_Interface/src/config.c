#include "config.h"

char prompt[CONSOLE_PROMPT_MAX_LEN];