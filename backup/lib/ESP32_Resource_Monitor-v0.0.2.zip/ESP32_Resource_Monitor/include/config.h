﻿#pragma once

#define CONFIG_TASKMONITOR_DUMP_INTERVAL     2
#define CONFIG_TASKMON_MAX_TASKS            40
#define CONFIG_DEBUG_TASKS                   1
#define CONFIG_DEBUG_MEMORY                  1
#define CONFIG_DEBUG_MEMORY_USE_PRINTF       1
#define CONFIG_DEBUG_ESP_TIMERS              1
#define CONFIG_MEMORY_DUMP                   0
#define CONFIG_TIME_STAMP_ON                 1
#define CONFIG_USE_ESP_TIMER                 0
#define CONFIG_RESMON_USE_ESP_TIMER_DISPATCH 0