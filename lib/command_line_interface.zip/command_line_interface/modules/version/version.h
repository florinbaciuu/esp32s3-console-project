#pragma once


#ifndef VERSION_H_
#define VERSION_H_


#ifdef __cplusplus
extern "C" {
#endif /* #ifdef __cplusplus */

void cli_register_version_commands(void);


#ifdef __cplusplus
}
#endif /* #ifdef __cplusplus */

#endif  /* #ifndef VERSION_H_ */